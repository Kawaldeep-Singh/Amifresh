'use client';

import { useState, useEffect, useRef } from 'react';
import { Search, MapPin, User, FileText, ChevronRight } from 'lucide-react';
import { Skeleton } from '@/components/ui/Skeleton';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

interface SearchResult {
  type: 'route' | 'user';
  title: string;
  subtitle?: string;
  href: string;
}

export function GlobalSearch() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const wrapperRef = useRef<HTMLDivElement>(null);
  const router = useRouter();

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    const fetchResults = async () => {
      if (query.trim().length < 2) {
        setResults([]);
        return;
      }

      setIsLoading(true);
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
        if (res.ok) {
          const data = await res.json();
          setResults(data.results || []);
        }
      } catch (error) {
        console.error('Search error:', error);
      } finally {
        setIsLoading(false);
      }
    };

    const timeoutId = setTimeout(fetchResults, 300);
    return () => clearTimeout(timeoutId);
  }, [query]);

  const handleSelect = (href: string) => {
    setIsOpen(false);
    setQuery('');
    router.push(href);
  };

  return (
    <div ref={wrapperRef} className="w-full max-w-md relative text-gray-400 focus-within:text-primary">
      <div className="absolute inset-y-0 left-0 flex items-center pointer-events-none pl-3">
        <Search className="h-5 w-5" aria-hidden="true" />
      </div>
      <input
        id="search"
        className="block w-full h-full pl-10 pr-3 py-2 border border-gray-200 text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-primary focus:border-primary sm:text-sm bg-gray-50 hover:bg-white focus:bg-white rounded-lg shadow-sm transition-all"
        placeholder="Search users, orders, or pages..."
        type="search"
        value={query}
        onChange={(e) => {
          setQuery(e.target.value);
          setIsOpen(true);
        }}
        onFocus={() => {
          if (query.trim().length >= 2) setIsOpen(true);
        }}
      />

      {isOpen && query.trim().length >= 2 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-surface rounded-lg shadow-xl border border-border overflow-hidden z-50 max-h-96 overflow-y-auto">
          {isLoading ? (
            <div className="p-3 space-y-2">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center gap-3 p-2">
                  <Skeleton className="h-8 w-8 rounded-full shrink-0" />
                  <div className="space-y-1.5 flex-1">
                    <Skeleton className="h-3.5 w-3/4" />
                    <Skeleton className="h-2.5 w-1/2" />
                  </div>
                </div>
              ))}
            </div>
          ) : results.length > 0 ? (
            <div className="py-2">
              {results.map((result, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSelect(result.href)}
                  className="w-full text-left px-4 py-3 hover:bg-bg flex items-center gap-3 transition-colors border-b border-border last:border-0"
                >
                  <div className={`p-2 rounded-full ${result.type === 'route' ? 'bg-primary-light text-primary' : 'bg-primary-light text-primary'}`}>
                    {result.type === 'route' ? <FileText size={16} /> : <User size={16} />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-text-main truncate">{result.title}</p>
                    {result.subtitle && (
                      <p className="text-xs text-text-muted truncate">{result.subtitle}</p>
                    )}
                  </div>
                  <ChevronRight size={16} className="text-text-muted" />
                </button>
              ))}
            </div>
          ) : (
            <div className="p-4 text-center text-sm text-text-muted">
              No results found for "{query}"
            </div>
          )}
        </div>
      )}
    </div>
  );
}
