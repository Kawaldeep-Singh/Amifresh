1:"$Sreact.fragment"
2:"/_next/static/chunks/2aop0b303i9l1.js"
3:I[32878,["$2"],"default"]
4:I[39756,["$2"],"default"]
5:I[37457,["$2"],"default"]
6:"/_next/static/chunks/2r5v411hyppyg.js"
7:I[5500,["$2","$6"],"Image"]
8:I[22016,["$2","$6"],""]
d:"LoadingBoundaryProvider"
e:I[39756,["$2"],"$d"]
1f:"ViewportBoundary"
20:I[97367,["$2"],"$1f"]
21:"MetadataBoundary"
22:I[97367,["$2"],"$21"]
23:"$Sreact.suspense"
24:I[27201,["$2"],"IconMark"]
:HL["/_next/static/chunks/22m2ge1zt6uyi.css","style"]
:HL["/_next/static/chunks/40gb-elqt4uic.css","style"]
a:X
a:C
b:X
b:300
b:C
13:X
13:C
17:X
17:C
1b:X
1b:C
1c:[["children",{"s":"__PAGE__","h":162,"d":{"r":"$L1d","p":"$@1e","v":"$1b","s":"$b"}}]]
18:[["children",{"s":"registrations","h":98,"d":{"r":"$L19","p":"$@1a","v":"$1b","s":"$b"},"c":"$Q1c"}]]
14:[["children",{"s":"admin","h":98,"d":{"r":"$L15","p":"$@16","v":"$17","s":"$b"},"c":"$Q18"}]]
c:[["children",{"s":"(dashboard)","h":102,"d":{"r":["$","$Le",null,{"loading":[["$","div","l",{"className":"p-6 space-y-6 animate-pulse w-full max-w-7xl mx-auto","children":[["$","div",null,{"className":"flex flex-col gap-2","children":[["$","div",null,{"className":"h-7 bg-gray-200 rounded-lg w-56"}],["$","div",null,{"className":"h-4 bg-gray-200 rounded-lg w-80"}]]}],["$","div",null,{"className":"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-6","children":[["$","div","1",{"className":"bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4","children":[["$","div",null,{"className":"h-12 w-12 bg-gray-100 rounded-full shrink-0"}],["$","div",null,{"className":"space-y-2 flex-1","children":[["$","div",null,{"className":"h-3.5 bg-gray-200 rounded w-20"}],["$","div",null,{"className":"h-6 bg-gray-200 rounded w-14"}]]}]]}],["$","div","2",{"className":"bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4","children":[["$","div",null,{"className":"h-12 w-12 bg-gray-100 rounded-full shrink-0"}],["$","div",null,{"className":"space-y-2 flex-1","children":[["$","div",null,{"className":"h-3.5 bg-gray-200 rounded w-20"}],["$","div",null,{"className":"h-6 bg-gray-200 rounded w-14"}]]}]]}],["$","div","3",{"className":"bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4","children":[["$","div",null,{"className":"h-12 w-12 bg-gray-100 rounded-full shrink-0"}],["$","div",null,{"className":"space-y-2 flex-1","children":[["$","div",null,{"className":"h-3.5 bg-gray-200 rounded w-20"}],["$","div",null,{"className":"h-6 bg-gray-200 rounded w-14"}]]}]]}],"$Lf"]}],"$L10"]}],[],null],"children":"$L11"}],"p":"$@12","v":"$13","s":"$b"},"c":"$Q14"}]]
26:X
26:C
29:X
29:C
0:{"t":{"t":{"s":"","h":90,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/22m2ge1zt6uyi.css","precedence":"next"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/chunks/40gb-elqt4uic.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/2aop0b303i9l1.js","async":true}]],["$","html",null,{"lang":"en","className":"Gsdoiq_variable h-full antialiased","suppressHydrationWarning":true,"children":["$","body",null,{"className":"min-h-full flex flex-col","suppressHydrationWarning":true,"children":["$","$L3",null,{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}],"notFound":[["$","div",null,{"className":"flex flex-col min-h-screen bg-bg items-center justify-center p-4","children":[["$","div",null,{"className":"mb-10 animate-fade-in-up","children":["$","$L7",null,{"src":"/amifresh-dark-thema.webp","alt":"Amifresh Logo","width":200,"height":60,"className":"object-contain"}]}],["$","div",null,{"className":"bg-white p-8 md:p-12 rounded-3xl shadow-xl border border-gray-100 text-center max-w-lg w-full relative overflow-hidden","children":[["$","div",null,{"className":"absolute -top-16 -right-16 w-32 h-32 bg-primary/10 rounded-full blur-2xl"}],["$","div",null,{"className":"absolute -bottom-16 -left-16 w-40 h-40 bg-orange-500/10 rounded-full blur-2xl"}],["$","div",null,{"className":"relative z-10","children":[["$","h1",null,{"className":"text-8xl md:text-9xl font-black text-transparent bg-clip-text bg-gradient-to-br from-primary to-orange-500 mb-2 drop-shadow-sm","children":"404"}],["$","h2",null,{"className":"text-2xl md:text-3xl font-bold text-gray-900 mb-4","children":"Oops! Page not found"}],["$","p",null,{"className":"text-gray-600 mb-8 leading-relaxed","children":"The page you are looking for might have been removed, had its name changed, or is temporarily unavailable. Maybe you wandered too far into the spice route!"}],["$","$L8",null,{"href":"/","className":"inline-flex items-center justify-center px-8 py-4 border border-transparent text-base font-bold rounded-xl text-white bg-gradient-to-r from-primary to-orange-500 hover:from-primary-dark hover:to-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1","children":"Return to Dashboard"}]]}]]}],["$","div",null,{"className":"mt-12 text-sm text-gray-400 font-medium","children":"© 2024 Amifresh. All rights reserved."}]]}],[]]}]}]}]}]]}],"p":"$@9","v":"$a","s":"$b"},"c":"$Qc"},"h":{"r":["$","$1","h",{"children":[null,["$","$L20",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","$L22",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$23",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Amifresh Admin & Referral System"}],["$","meta","1",{"name":"description","content":"Complete Admin, Referral & Network Management System"}],["$","link","2",{"rel":"icon","href":"/favicon.png"}],["$","$L24","3",{}]]}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":"$@25","v":"$26","s":"$b"}},"a":"$@27","u":"$@28","b":"IacmipwQ1r_BX-0jK1mR1","r":"$29"}
2a:"/_next/static/chunks/2_vrlx5ulxmi5.js"
2b:I[79425,["$2","$2a"],"DashboardLayout"]
2d:I[47257,["$2"],"ClientPageRoot"]
2e:"/_next/static/chunks/2l38l1yny7y3-.js"
2f:I[82092,["$2","$2a","$2e"],"default"]
30:I[97367,["$2"],"OutletBoundary"]
f:["$","div","4",{"className":"bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4","children":[["$","div",null,{"className":"h-12 w-12 bg-gray-100 rounded-full shrink-0"}],["$","div",null,{"className":"space-y-2 flex-1","children":[["$","div",null,{"className":"h-3.5 bg-gray-200 rounded w-20"}],["$","div",null,{"className":"h-6 bg-gray-200 rounded w-14"}]]}]]}]
10:["$","div",null,{"className":"grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6","children":[["$","div",null,{"className":"bg-white p-6 rounded-xl border border-gray-100 shadow-sm h-64","children":[["$","div",null,{"className":"h-5 bg-gray-200 rounded w-36 mb-4"}],["$","div",null,{"className":"h-40 bg-gray-100 rounded-lg"}]]}],["$","div",null,{"className":"bg-white p-6 rounded-xl border border-gray-100 shadow-sm h-64","children":[["$","div",null,{"className":"h-5 bg-gray-200 rounded w-36 mb-4"}],["$","div",null,{"className":"h-40 bg-gray-100 rounded-lg"}]]}]]}]
11:["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/2_vrlx5ulxmi5.js","async":true}]],["$","$L2b",null,{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}],"notFound":[["$","div",null,{"className":"flex flex-col min-h-screen bg-bg items-center justify-center p-4","children":[["$","div",null,{"className":"mb-10 animate-fade-in-up","children":["$","$L7",null,{"src":"/amifresh-dark-thema.webp","alt":"Amifresh Logo","width":200,"height":60,"className":"object-contain"}]}],["$","div",null,{"className":"bg-white p-8 md:p-12 rounded-3xl shadow-xl border border-gray-100 text-center max-w-lg w-full relative overflow-hidden","children":[["$","div",null,{"className":"absolute -top-16 -right-16 w-32 h-32 bg-primary/10 rounded-full blur-2xl"}],["$","div",null,{"className":"absolute -bottom-16 -left-16 w-40 h-40 bg-orange-500/10 rounded-full blur-2xl"}],["$","div",null,{"className":"relative z-10","children":[["$","h1",null,{"className":"text-8xl md:text-9xl font-black text-transparent bg-clip-text bg-gradient-to-br from-primary to-orange-500 mb-2 drop-shadow-sm","children":"404"}],["$","h2",null,{"className":"text-2xl md:text-3xl font-bold text-gray-900 mb-4","children":"Oops! Page not found"}],["$","p",null,{"className":"text-gray-600 mb-8 leading-relaxed","children":"The page you are looking for might have been removed, had its name changed, or is temporarily unavailable. Maybe you wandered too far into the spice route!"}],["$","$L8",null,{"href":"/","className":"inline-flex items-center justify-center px-8 py-4 border border-transparent text-base font-bold rounded-xl text-white bg-gradient-to-r from-primary to-orange-500 hover:from-primary-dark hover:to-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1","children":"Return to Dashboard"}]]}]]}],["$","div",null,{"className":"mt-12 text-sm text-gray-400 font-medium","children":"© 2024 Amifresh. All rights reserved."}]]}],[]]}]}]]}]
15:["$","$1","c",{"children":[null,"$L2c"]}]
19:["$","$1","c",{"children":[null,["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]]}]
1d:["$","$1","c",{"children":[["$","$L2d",null,{"Component":"$2f","serverProvidedParams":null}],[["$","script","script-0",{"src":"/_next/static/chunks/2l38l1yny7y3-.js","async":true}]],["$","$L30",null,{"children":["$","$23",null,{"name":"Next.MetadataOutlet","children":"$@31"}]}]]}]
28:true
31:null
27:null
1a:"$undefined"
9:"$undefined"
25:"$undefined"
1e:"$undefined"
12:"$undefined"
