1:"$Sreact.fragment"
2:"/_next/static/chunks/2aop0b303i9l1.js"
3:I[32878,["$2"],"default"]
4:I[39756,["$2"],"default"]
5:I[37457,["$2"],"default"]
6:"/_next/static/chunks/2r5v411hyppyg.js"
7:I[5500,["$2","$6"],"Image"]
8:"/_next/static/chunks/2_vrlx5ulxmi5.js"
9:I[22016,["$2","$8"],""]
c:"LoadingBoundaryProvider"
d:I[39756,["$2"],"$c"]
1c:"ViewportBoundary"
1d:I[97367,["$2"],"$1c"]
1f:"MetadataBoundary"
20:I[97367,["$2"],"$1f"]
21:"$Sreact.suspense"
24:I[68027,["$2"],"default",1]
:HL["/_next/static/chunks/22m2ge1zt6uyi.css","style"]
:HL["/_next/static/chunks/40gb-elqt4uic.css","style"]
:HL["/_next/static/media/07454f8ad8aaac57-s.p.2kjei9psvcorz.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/47fe1b7cd6e6ed85-s.p.3bh2vc0w-r-ll.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/829ba4228c966254-s.p.2mm3nq9i83l-m.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/8495c7a64396f454-s.p.3174gmb7yd72v.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/8e6fa89aa22d24ec-s.p.2o7m9ogm38dql.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/a218039a3287bcfd-s.p.43zbiuwnnoiok.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/e2334d715941921e-s.p.3o_v2fun1jzxk.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
a:X
12:X
15:X
18:X
1b:X
19:[["children",{"s":"__PAGE__","h":514,"d":{"r":"$L1a","p":true,"v":"$1b"}}]]
16:[["children",{"s":"profile","h":514,"d":{"r":"$L17","p":true,"v":"$18"},"c":"$Q19"}]]
13:[["children",{"s":"sakhi","h":8706,"d":{"r":"$L14","p":true,"v":"$15"},"c":"$Q16"}]]
b:[["children",{"s":"(dashboard)","h":8710,"d":{"r":["$","$Ld",null,{"loading":[["$","div","l",{"className":"p-6 space-y-6 animate-pulse w-full max-w-7xl mx-auto","children":[["$","div",null,{"className":"flex flex-col gap-2","children":[["$","div",null,{"className":"h-7 bg-gray-200 rounded-lg w-56"}],["$","div",null,{"className":"h-4 bg-gray-200 rounded-lg w-80"}]]}],["$","div",null,{"className":"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-6","children":[["$","div","1",{"className":"bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4","children":[["$","div",null,{"className":"h-12 w-12 bg-gray-100 rounded-full shrink-0"}],["$","div",null,{"className":"space-y-2 flex-1","children":[["$","div",null,{"className":"h-3.5 bg-gray-200 rounded w-20"}],["$","div",null,{"className":"h-6 bg-gray-200 rounded w-14"}]]}]]}],["$","div","2",{"className":"bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4","children":[["$","div",null,{"className":"h-12 w-12 bg-gray-100 rounded-full shrink-0"}],["$","div",null,{"className":"space-y-2 flex-1","children":[["$","div",null,{"className":"h-3.5 bg-gray-200 rounded w-20"}],["$","div",null,{"className":"h-6 bg-gray-200 rounded w-14"}]]}]]}],["$","div","3",{"className":"bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4","children":[["$","div",null,{"className":"h-12 w-12 bg-gray-100 rounded-full shrink-0"}],"$Le"]}],"$Lf"]}],"$L10"]}],[],null],"children":"$L11"}],"p":true,"v":"$12"},"c":"$Q13"}]]
23:X
25:X
26:X
0:{"P":null,"c":["","sakhi","profile"],"q":"","i":false,"t":{"t":{"s":"","h":8730,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/22m2ge1zt6uyi.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/chunks/40gb-elqt4uic.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/2aop0b303i9l1.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en","className":"Gsdoiq_variable h-full antialiased","suppressHydrationWarning":true,"children":["$","body",null,{"className":"min-h-full flex flex-col","suppressHydrationWarning":true,"children":["$","$L3",null,{"children":["$","$L4",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L5",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","div",null,{"className":"flex flex-col min-h-screen bg-bg items-center justify-center p-4","children":[["$","div",null,{"className":"mb-10 animate-fade-in-up","children":["$","$L7",null,{"src":"/amifresh-dark-thema.webp","alt":"Amifresh Logo","width":200,"height":60,"className":"object-contain"}]}],["$","div",null,{"className":"bg-white p-8 md:p-12 rounded-3xl shadow-xl border border-gray-100 text-center max-w-lg w-full relative overflow-hidden","children":[["$","div",null,{"className":"absolute -top-16 -right-16 w-32 h-32 bg-primary/10 rounded-full blur-2xl"}],["$","div",null,{"className":"absolute -bottom-16 -left-16 w-40 h-40 bg-orange-500/10 rounded-full blur-2xl"}],["$","div",null,{"className":"relative z-10","children":[["$","h1",null,{"className":"text-8xl md:text-9xl font-black text-transparent bg-clip-text bg-gradient-to-br from-primary to-orange-500 mb-2 drop-shadow-sm","children":"404"}],["$","h2",null,{"className":"text-2xl md:text-3xl font-bold text-gray-900 mb-4","children":"Oops! Page not found"}],["$","p",null,{"className":"text-gray-600 mb-8 leading-relaxed","children":"The page you are looking for might have been removed, had its name changed, or is temporarily unavailable. Maybe you wandered too far into the spice route!"}],["$","$L9",null,{"href":"/","className":"inline-flex items-center justify-center px-8 py-4 border border-transparent text-base font-bold rounded-xl text-white bg-gradient-to-r from-primary to-orange-500 hover:from-primary-dark hover:to-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1","children":"Return to Dashboard"}]]}]]}],["$","div",null,{"className":"mt-12 text-sm text-gray-400 font-medium","children":"© 2024 Amifresh. All rights reserved."}]]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]}]]}],"p":true,"v":"$a"},"c":"$Qb"},"h":{"r":["$","$1","h",{"children":[null,["$","$L1d",null,{"children":"$L1e"}],["$","$L20",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$21",null,{"name":"Next.Metadata","children":"$L22"}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":true,"v":"$23"}},"m":"$undefined","G":["$24",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/22m2ge1zt6uyi.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/chunks/40gb-elqt4uic.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$25","s":"$26","a":"$@27","l":"$undefined","p":"$undefined","d":"$undefined","b":"IacmipwQ1r_BX-0jK1mR1","u":"$@28"}
29:I[79425,["$2","$8"],"DashboardLayout"]
2c:I[97367,["$2"],"OutletBoundary"]
e:["$","div",null,{"className":"space-y-2 flex-1","children":[["$","div",null,{"className":"h-3.5 bg-gray-200 rounded w-20"}],["$","div",null,{"className":"h-6 bg-gray-200 rounded w-14"}]]}]
f:["$","div","4",{"className":"bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4","children":[["$","div",null,{"className":"h-12 w-12 bg-gray-100 rounded-full shrink-0"}],["$","div",null,{"className":"space-y-2 flex-1","children":[["$","div",null,{"className":"h-3.5 bg-gray-200 rounded w-20"}],["$","div",null,{"className":"h-6 bg-gray-200 rounded w-14"}]]}]]}]
10:["$","div",null,{"className":"grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6","children":[["$","div",null,{"className":"bg-white p-6 rounded-xl border border-gray-100 shadow-sm h-64","children":[["$","div",null,{"className":"h-5 bg-gray-200 rounded w-36 mb-4"}],["$","div",null,{"className":"h-40 bg-gray-100 rounded-lg"}]]}],["$","div",null,{"className":"bg-white p-6 rounded-xl border border-gray-100 shadow-sm h-64","children":[["$","div",null,{"className":"h-5 bg-gray-200 rounded w-36 mb-4"}],["$","div",null,{"className":"h-40 bg-gray-100 rounded-lg"}]]}]]}]
11:["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/2_vrlx5ulxmi5.js","async":true,"nonce":"$undefined"}]],["$","$L29",null,{"children":["$","$L4",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L5",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[["$","div",null,{"className":"flex flex-col min-h-screen bg-bg items-center justify-center p-4","children":[["$","div",null,{"className":"mb-10 animate-fade-in-up","children":["$","$L7",null,{"src":"/amifresh-dark-thema.webp","alt":"Amifresh Logo","width":200,"height":60,"className":"object-contain"}]}],["$","div",null,{"className":"bg-white p-8 md:p-12 rounded-3xl shadow-xl border border-gray-100 text-center max-w-lg w-full relative overflow-hidden","children":[["$","div",null,{"className":"absolute -top-16 -right-16 w-32 h-32 bg-primary/10 rounded-full blur-2xl"}],["$","div",null,{"className":"absolute -bottom-16 -left-16 w-40 h-40 bg-orange-500/10 rounded-full blur-2xl"}],["$","div",null,{"className":"relative z-10","children":[["$","h1",null,{"className":"text-8xl md:text-9xl font-black text-transparent bg-clip-text bg-gradient-to-br from-primary to-orange-500 mb-2 drop-shadow-sm","children":"404"}],["$","h2",null,{"className":"text-2xl md:text-3xl font-bold text-gray-900 mb-4","children":"Oops! Page not found"}],["$","p",null,{"className":"text-gray-600 mb-8 leading-relaxed","children":"The page you are looking for might have been removed, had its name changed, or is temporarily unavailable. Maybe you wandered too far into the spice route!"}],["$","$L9",null,{"href":"/","className":"inline-flex items-center justify-center px-8 py-4 border border-transparent text-base font-bold rounded-xl text-white bg-gradient-to-r from-primary to-orange-500 hover:from-primary-dark hover:to-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1","children":"Return to Dashboard"}]]}]]}],["$","div",null,{"className":"mt-12 text-sm text-gray-400 font-medium","children":"© 2024 Amifresh. All rights reserved."}]]}],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]]}]
14:["$","$1","c",{"children":[null,"$L2a"]}]
17:["$","$1","c",{"children":[null,["$","$L4",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L5",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}]
1a:["$","$1","c",{"children":["$L2b",null,["$","$L2c",null,{"children":["$","$21",null,{"name":"Next.MetadataOutlet","children":"$@2d"}]}]]}]
18:C
26:300
28:true
1e:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
2e:I[27201,["$2"],"IconMark"]
22:[["$","title","0",{"children":"Amifresh Admin & Referral System"}],["$","meta","1",{"name":"description","content":"Complete Admin, Referral & Network Management System"}],["$","link","2",{"rel":"icon","href":"/favicon.png"}],["$","$L2e","3",{}]]
2d:null
26:C
23:C
25:C
1b:C
15:C
12:C
a:C
27:null
