module.exports=[59962,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_employees_route_actions_040bb182cfl08.js.map