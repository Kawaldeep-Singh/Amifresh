1:"$Sreact.fragment"
2:"/_next/static/chunks/2aop0b303i9l1.js"
3:I[32878,["$2"],"default"]
4:I[39756,["$2"],"default"]
5:I[37457,["$2"],"default"]
6:"/_next/static/chunks/2r5v411hyppyg.js"
7:I[5500,["$2","$6"],"Image"]
8:I[22016,["$2","$6"],""]
d:"LoadingBoundaryProvider"
e:I[39756,["$2"],"$d"]
20:"ViewportBoundary"
21:I[97367,["$2"],"$20"]
22:"MetadataBoundary"
23:I[97367,["$2"],"$22"]
24:"$Sreact.suspense"
25:I[27201,["$2"],"IconMark"]
:HL["/_next/static/chunks/22m2ge1zt6uyi.css","style"]
:HL["/_next/static/chunks/40gb-elqt4uic.css","style"]
a:X
a:C
b:X
b:300
b:C
13:X
13:C
17:X
17:C
1b:X
1b:C
1f:X
1f:C
1c:[["children",{"s":"__PAGE__","h":49314,"d":{"r":"$L1d","p":"$@1e","v":"$1f","s":"$b"}}]]
18:[["children",{"s":"registrations","h":49250,"d":{"r":"$L19","p":"$@1a","v":"$1b","s":"$b"},"c":"$Q1c"}]]
14:[["children",{"s":"team","h":57442,"d":{"r":"$L15","p":"$@16","v":"$17","s":"$b"},"c":"$Q18"}]]
c:[["children",{"s":"(dashboard)","h":57446,"d":{"r":["$","$Le",null,{"loading":[["$","div","l",{"className":"p-6 space-y-6 animate-pulse w-full max-w-7xl mx-auto","children":[["$","div",null,{"className":"flex flex-col gap-2","children":[["$","div",null,{"className":"h-7 bg-gray-200 rounded-lg w-56"}],["$","div",null,{"className":"h-4 bg-gray-200 rounded-lg w-80"}]]}],["$","div",null,{"className":"grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-6","children":[["$","div","1",{"className":"bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4","children":[["$","div",null,{"className":"h-12 w-12 bg-gray-100 rounded-full shrink-0"}],["$","div",null,{"className":"space-y-2 flex-1","children":[["$","div",null,{"className":"h-3.5 bg-gray-200 rounded w-20"}],["$","div",null,{"className":"h-6 bg-gray-200 rounded w-14"}]]}]]}],["$","div","2",{"className":"bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4","children":[["$","div",null,{"className":"h-12 w-12 bg-gray-100 rounded-full shrink-0"}],["$","div",null,{"className":"space-y-2 flex-1","children":[["$","div",null,{"className":"h-3.5 bg-gray-200 rounded w-20"}],["$","div",null,{"className":"h-6 bg-gray-200 rounded w-14"}]]}]]}],["$","div","3",{"className":"bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4","children":[["$","div",null,{"className":"h-12 w-12 bg-gray-100 rounded-full shrink-0"}],["$","div",null,{"className":"space-y-2 flex-1","children":[["$","div",null,{"className":"h-3.5 bg-gray-200 rounded w-20"}],["$","div",null,{"className":"h-6 bg-gray-200 rounded w-14"}]]}]]}],"$Lf"]}],"$L10"]}],[],null],"children":"$L11"}],"p":"$@12","v":"$13","s":"$b"},"c":"$Q14"}]]
27:X
27:C
2a:X
2a:C
0:{"t":{"t":{"s":"","h":57434,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/22m2ge1zt6uyi.css","precedence":"next"}],["$","link","1",{"rel":"stylesheet","href":"/_next/static/chunks/40gb-elqt4uic.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/2aop0b303i9l1.js","async":true}]],["$","html",null,{"lang":"en","className":"Gsdoiq_variable h-full antialiased","suppressHydrationWarning":true,"children":["$","body",null,{"className":"min-h-full flex flex-col","suppressHydrationWarning":true,"children":["$","$L3",null,{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}],"notFound":[["$","div",null,{"className":"flex flex-col min-h-screen bg-bg items-center justify-center p-4","children":[["$","div",null,{"className":"mb-10 animate-fade-in-up","children":["$","$L7",null,{"src":"/amifresh-dark-thema.webp","alt":"Amifresh Logo","width":200,"height":60,"className":"object-contain"}]}],["$","div",null,{"className":"bg-white p-8 md:p-12 rounded-3xl shadow-xl border border-gray-100 text-center max-w-lg w-full relative overflow-hidden","children":[["$","div",null,{"className":"absolute -top-16 -right-16 w-32 h-32 bg-primary/10 rounded-full blur-2xl"}],["$","div",null,{"className":"absolute -bottom-16 -left-16 w-40 h-40 bg-orange-500/10 rounded-full blur-2xl"}],["$","div",null,{"className":"relative z-10","children":[["$","h1",null,{"className":"text-8xl md:text-9xl font-black text-transparent bg-clip-text bg-gradient-to-br from-primary to-orange-500 mb-2 drop-shadow-sm","children":"404"}],["$","h2",null,{"className":"text-2xl md:text-3xl font-bold text-gray-900 mb-4","children":"Oops! Page not found"}],["$","p",null,{"className":"text-gray-600 mb-8 leading-relaxed","children":"The page you are looking for might have been removed, had its name changed, or is temporarily unavailable. Maybe you wandered too far into the spice route!"}],["$","$L8",null,{"href":"/","className":"inline-flex items-center justify-center px-8 py-4 border border-transparent text-base font-bold rounded-xl text-white bg-gradient-to-r from-primary to-orange-500 hover:from-primary-dark hover:to-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1","children":"Return to Dashboard"}]]}]]}],["$","div",null,{"className":"mt-12 text-sm text-gray-400 font-medium","children":"© 2024 Amifresh. All rights reserved."}]]}],[]]}]}]}]}]]}],"p":"$@9","v":"$a","s":"$b"},"c":"$Qc"},"h":{"r":["$","$1","h",{"children":[null,["$","$L21",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]}],["$","$L23",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$24",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Amifresh Admin & Referral System"}],["$","meta","1",{"name":"description","content":"Complete Admin, Referral & Network Management System"}],["$","link","2",{"rel":"icon","href":"/favicon.png"}],["$","$L25","3",{}]]}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":"$@26","v":"$27","s":"$b"}},"a":"$@28","u":"$@29","b":"IacmipwQ1r_BX-0jK1mR1","r":"$2a"}
2b:"/_next/static/chunks/2_vrlx5ulxmi5.js"
2c:I[79425,["$2","$2b"],"DashboardLayout"]
2e:I[5014,["$2","$2b"],"default"]
2f:I[97367,["$2"],"OutletBoundary"]
f:["$","div","4",{"className":"bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex items-center gap-4","children":[["$","div",null,{"className":"h-12 w-12 bg-gray-100 rounded-full shrink-0"}],["$","div",null,{"className":"space-y-2 flex-1","children":[["$","div",null,{"className":"h-3.5 bg-gray-200 rounded w-20"}],["$","div",null,{"className":"h-6 bg-gray-200 rounded w-14"}]]}]]}]
10:["$","div",null,{"className":"grid grid-cols-1 lg:grid-cols-2 gap-6 mt-6","children":[["$","div",null,{"className":"bg-white p-6 rounded-xl border border-gray-100 shadow-sm h-64","children":[["$","div",null,{"className":"h-5 bg-gray-200 rounded w-36 mb-4"}],["$","div",null,{"className":"h-40 bg-gray-100 rounded-lg"}]]}],["$","div",null,{"className":"bg-white p-6 rounded-xl border border-gray-100 shadow-sm h-64","children":[["$","div",null,{"className":"h-5 bg-gray-200 rounded w-36 mb-4"}],["$","div",null,{"className":"h-40 bg-gray-100 rounded-lg"}]]}]]}]
11:["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/2_vrlx5ulxmi5.js","async":true}]],["$","$L2c",null,{"children":["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}],"notFound":[["$","div",null,{"className":"flex flex-col min-h-screen bg-bg items-center justify-center p-4","children":[["$","div",null,{"className":"mb-10 animate-fade-in-up","children":["$","$L7",null,{"src":"/amifresh-dark-thema.webp","alt":"Amifresh Logo","width":200,"height":60,"className":"object-contain"}]}],["$","div",null,{"className":"bg-white p-8 md:p-12 rounded-3xl shadow-xl border border-gray-100 text-center max-w-lg w-full relative overflow-hidden","children":[["$","div",null,{"className":"absolute -top-16 -right-16 w-32 h-32 bg-primary/10 rounded-full blur-2xl"}],["$","div",null,{"className":"absolute -bottom-16 -left-16 w-40 h-40 bg-orange-500/10 rounded-full blur-2xl"}],["$","div",null,{"className":"relative z-10","children":[["$","h1",null,{"className":"text-8xl md:text-9xl font-black text-transparent bg-clip-text bg-gradient-to-br from-primary to-orange-500 mb-2 drop-shadow-sm","children":"404"}],["$","h2",null,{"className":"text-2xl md:text-3xl font-bold text-gray-900 mb-4","children":"Oops! Page not found"}],["$","p",null,{"className":"text-gray-600 mb-8 leading-relaxed","children":"The page you are looking for might have been removed, had its name changed, or is temporarily unavailable. Maybe you wandered too far into the spice route!"}],["$","$L8",null,{"href":"/","className":"inline-flex items-center justify-center px-8 py-4 border border-transparent text-base font-bold rounded-xl text-white bg-gradient-to-r from-primary to-orange-500 hover:from-primary-dark hover:to-orange-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary shadow-lg hover:shadow-xl transition-all transform hover:-translate-y-1","children":"Return to Dashboard"}]]}]]}],["$","div",null,{"className":"mt-12 text-sm text-gray-400 font-medium","children":"© 2024 Amifresh. All rights reserved."}]]}],[]]}]}]]}]
15:["$","$1","c",{"children":[null,"$L2d"]}]
19:["$","$1","c",{"children":[null,["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}]}]]}]
1d:["$","$1","c",{"children":[["$","div",null,{"className":"space-y-6","children":[["$","div",null,{"className":"flex items-center justify-between","children":["$","h1",null,{"className":"text-2xl font-bold text-gray-900","children":"Team Registrations"}]}],["$","div",null,{"className":"flex flex-col items-center justify-center min-h-[400px] p-8 text-center bg-surface rounded-xl border border-border shadow-sm","children":[["$","div",null,{"className":"flex items-center justify-center w-16 h-16 mb-4 rounded-full bg-primary-light","children":["$","$L2e",null,{"icon":{"name":"user-plus","size":24,"node":[["path",{"d":"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2","key":"1yyitq"}],["circle",{"cx":"9","cy":"7","r":"4","key":"nufk8"}],["line",{"x1":"19","x2":"19","y1":"8","y2":"14","key":"1bvyxn"}],["line",{"x1":"22","x2":"16","y1":"11","y2":"11","key":"1shjgl"}]]},"className":"w-8 h-8 text-primary"}]}],["$","h3",null,{"className":"mb-2 text-xl font-semibold text-text-main","children":"Pending Sakhi"}],["$","p",null,{"className":"max-w-sm text-sm text-text-muted","children":"Pending team registrations will appear here for your review and approval in a future update."}]]}]]}],null,["$","$L2f",null,{"children":["$","$24",null,{"name":"Next.MetadataOutlet","children":"$@30"}]}]]}]
29:false
30:null
28:null
1a:"$undefined"
9:"$undefined"
26:"$undefined"
1e:"$undefined"
12:"$undefined"
